from sqlalchemy import Column, Integer, String, Text, ForeignKey
from config.database import Base

class Wisata(Base):
    __tablename__ = "wisata"

    id_wisata = Column(Integer, primary_key=True, index=True, autoincrement=True)
    nama_wisata = Column(String(100), nullable=False)
    lokasi = Column(String(100), nullable=False)
    deskripsi = Column(String(100), nullable=False)
    gambar = Column(String(255), nullable=True)
    id_kategori = Column(Integer,nullable=True)
