from sqlalchemy import Column, Integer, String
from config.database import Base

class Kategori(Base):
    __tablename__ = "kategori"

    id_kategori = Column(Integer, primary_key=True, index=True)
    kategori = Column(String, nullable=False)