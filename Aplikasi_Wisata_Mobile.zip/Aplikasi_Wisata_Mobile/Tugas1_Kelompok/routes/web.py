from flask import Blueprint
from controllers.wisata_controller import get_all_wisata, add_wisata, update_wisata, delete_wisata,get_wisata_by_kategori
from controllers.kategori_controller import get_all_kategori, add_kategori, update_kategori, delete_kategori

web = Blueprint("web", __name__)

# Endpoint API
web.route("/", methods=["GET"])(get_all_wisata)
web.route("/wisata/insert", methods=["POST"])(add_wisata)
web.route("/wisata/update/<int:id_wisata>", methods=["PUT"])(update_wisata)
web.route("/wisata/delete/<int:id_wisata>", methods=["DELETE"])(delete_wisata)
web.route("/wisata/kategori/<int:id_kategori>", methods=["GET"])(get_wisata_by_kategori)

web.route("/kategori", methods=["GET"])(get_all_kategori)
web.route("/kategori/insert", methods=["POST"])(add_kategori)
web.route("/kategori/update/<int:id_kategori>", methods=["PUT"])(update_kategori)
web.route("/kategori/delete/<int:id_kategori>", methods=["DELETE"])(delete_kategori)