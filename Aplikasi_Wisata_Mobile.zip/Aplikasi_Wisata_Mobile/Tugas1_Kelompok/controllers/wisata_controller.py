from flask import jsonify, request
from config.database import get_db
from models.wisata_model import Wisata
from models.kategori_model import Kategori
from sqlalchemy.orm import Session
from datetime import datetime

def get_all_wisata():
    db: Session = next(get_db())
    data = db.query(Wisata).all()
    return jsonify([{
        "id_wisata": k.id_wisata,
        "nama_wisata": k.nama_wisata,
        "lokasi": k.lokasi,
        "deskripsi": k.deskripsi,
        "gambar": k.gambar,
        "id_kategori": k.id_kategori,
    } for k in data])

def add_wisata():  
    db: Session = next(get_db())
    body = request.json

    new_data = Wisata(
        nama_wisata=body["nama_wisata"],
        lokasi=body["lokasi"],
        deskripsi=body["deskripsi"],
        gambar=body["gambar"],
        id_kategori=body["id_kategori"],
    )
    db.add(new_data)
    db.commit()
    db.refresh(new_data)

    return jsonify({
        "message": "Data berhasil ditambahkan",
        "data": {
            "id_wisata": new_data.id_wisata,
            "nama_wisata": new_data.nama_wisata,
            "lokasi": new_data.lokasi,
            "deskripsi": new_data.deskripsi,
            "gambar": new_data.gambar,
            "id_kategori": new_data.id_kategori,
        }
    }), 201

def update_wisata(id_wisata):
    db: Session = next(get_db())
    body = request.json

    wisata = db.query(Wisata).filter(Wisata.id_wisata == id_wisata).first()
    if not wisata:
        return jsonify({"message": "Wisata tidak ditemukan"}), 404

    # Update field sesuai data yang dikirim
    wisata.nama_wisata = body.get("nama_wisata", wisata.nama_wisata)
    wisata.lokasi = body.get("lokasi", wisata.lokasi)
    wisata.deskripsi = body.get("deskripsi", wisata.deskripsi)
    wisata.gambar = body.get("gambar", wisata.gambar)
    wisata.id_kategori = body.get("id_kategori", wisata.id_kategori)

    db.commit()
    db.refresh(wisata)

    return jsonify({
        "message": "Data berhasil diperbarui",
        "data": {
            "id_wisata": wisata.id_wisata,
            "nama_wisata": wisata.nama_wisata,
            "lokasi": wisata.lokasi,
            "deskripsi": wisata.deskripsi,
            "gambar": wisata.gambar,
            "id_kategori": wisata.id_kategori,
        }
    }), 200


# =========================
# DELETE DATA WISATA
# =========================
def delete_wisata(id_wisata):
    db: Session = next(get_db())
    wisata = db.query(Wisata).filter(Wisata.id_wisata == id_wisata).first()
    if not wisata:
        return jsonify({"message": "Wisata tidak ditemukan"}), 404

    db.delete(wisata)
    db.commit()

    return jsonify({"message": f"Data wisata dengan id {id_wisata} berhasil dihapus"}), 200
def get_wisata_by_kategori(id_kategori):
    db: Session = next(get_db())
    # Query dengan join antara Wisata dan Kategori berdasarkan id_kategori
    data = db.query(Wisata).join(Kategori, Wisata.id_kategori == Kategori.id_kategori)\
        .filter(Kategori.id_kategori == id_kategori).all()

    return jsonify([{
        "id_wisata": w.id_wisata,
        "nama_wisata": w.nama_wisata,
        "lokasi": w.lokasi,
        "deskripsi": w.deskripsi,
        "gambar": w.gambar,
        "id_kategori": w.id_kategori,
    } for w in data])